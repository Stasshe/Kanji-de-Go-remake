/*
 ("","",""),
 ("","$","$"),
 ("","$","$%"),
 ("竹林", "ちくりん$たけばやし", "竹が密集して生えている林$%") 
 ("竹林", "ちくりん$たけばやし", "竹が密集して生えている林$違う意味")
 */
 
import Foundation


struct KanjiListData {
    let easy = easyList
    let normal = normalList  
    let hard = hardList
    let extra = extraList
}

